<?php
session_start();
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';
require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/fpdf/fpdf.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 1. Alapadatok beállítása
$felhasznaloNev = $_SESSION['felhasznalo'] ?? 'Ismeretlen felhasználó';
$felhasznaloEmail = $_SESSION['email'] ?? 'mrclrozsa@gmail.com';  // ha nincs sessionben

// 2. Számla adatok (ezeket normálisan az űrlapból vagy adatbázisból veszed)
$datum = date('Y-m-d');
$szamlaSzam = "INV" . date("Ymd") . rand(1000, 9999);
$termekek = [
    ['termek' => 'Audi R8', 'ora' => 3, 'ar' => 180000]
];
$osszeg = 0;

// 3. PDF generálás
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'InnovTrade Számla', 0, 1, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, "Név: $felhasznaloNev", 0, 1);
$pdf->Cell(0, 10, "Email: $felhasznaloEmail", 0, 1);
$pdf->Cell(0, 10, "Dátum: $datum", 0, 1);
$pdf->Cell(0, 10, "Számlaszám: $szamlaSzam", 0, 1);
$pdf->Ln(10);

$pdf->Cell(60, 10, 'Autó', 1);
$pdf->Cell(30, 10, 'Óra', 1);
$pdf->Cell(50, 10, 'Óradíj (Ft)', 1);
$pdf->Cell(50, 10, 'Összesen (Ft)', 1);
$pdf->Ln();

foreach ($termekek as $tetel) {
    $auto = $tetel['termek'];
    $ora = $tetel['ora'];
    $ar = $tetel['ar'];
    $osszeg += $ora * $ar;

    $pdf->Cell(60, 10, $auto, 1);
    $pdf->Cell(30, 10, $ora, 1);
    $pdf->Cell(50, 10, number_format($ar, 0, ',', ' '), 1);
    $pdf->Cell(50, 10, number_format($ora * $ar, 0, ',', ' '), 1);
    $pdf->Ln();
}

$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Végösszeg: ' . number_format($osszeg, 0, ',', ' ') . ' Ft', 0, 1);

// 4. PDF mentése
$pdfPath = __DIR__ . '/szamla_' . md5($felhasznaloEmail) . '.pdf';
$pdf->Output('F', $pdfPath);

// 5. Email küldése
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'InnovTrade1999@gmail.com';
    $mail->Password = 'rmjopiibhdwpjoyk';
    $mail->SMTPSecure = 'ssl'; // <-- EZ A JAVÍTOTT SOR
    $mail->Port = 465;


    $mail->CharSet = 'UTF-8';
    $mail->setFrom('InnovTrade1999@gmail.com', 'InnovTrade');
    $mail->addAddress($felhasznaloEmail, $felhasznaloNev);
    $mail->addAttachment($pdfPath);

    $mail->isHTML(true);
    $mail->Subject = 'Foglalás visszaigazolás - Számla mellékelve';
    $mail->Body = "<h3>Kedves {$felhasznaloNev},</h3><p>Köszönjük foglalását. A számlát csatoltan küldjük.</p><p>Üdvözlettel,<br>InnovTrade</p>";

    $mail->send();
    echo "✅ Számla elküldve a következő címre: $felhasznaloEmail";
} catch (Exception $e) {
    echo "❌ Hiba az email küldés során: " . $mail->ErrorInfo;
}
?>
