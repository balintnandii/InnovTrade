
<?php
// pdf/pdf_generalas.php — dizájnos, UTF-8-as PDF generálás

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../fpdf/fpdf.php';

if (!isset($_SESSION['szamla_adatok'])) {
    exit("❌ Nincsenek számla adatok.");
}

$adatok = $_SESSION['szamla_adatok'];
$pdf = new FPDF();
$pdf->AddPage();

$pdf->AddFont('DejaVu','','DejaVuSansCondensed.php');
$pdf->SetFont('DejaVu','',14);
$pdf->SetTitle('InnovTrade Számla');
$pdf->SetAuthor('InnovTrade');

$pdf->SetTextColor(33, 37, 41);
$pdf->Cell(0, 10, 'InnovTrade Számla', 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('DejaVu','',11);
$pdf->Cell(0, 8, 'Név: ' . $adatok['felhasznalo_nev'], 0, 1);
$pdf->Cell(0, 8, 'Email: ' . $adatok['felhasznalo_email'], 0, 1);
$pdf->Cell(0, 8, 'Dátum: ' . $adatok['datum'], 0, 1);
$pdf->Cell(0, 8, 'Számlaszám: ' . $adatok['szamla_sorszam'], 0, 1);
$pdf->Ln(4);

// Táblázat fejléc
$pdf->SetFont('DejaVu','',11);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(60, 10, 'Autó', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Óra', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Óradíj (Ft)', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Összesen (Ft)', 1, 1, 'C', true);

// Sorok
$pdf->SetFont('DejaVu','',10);
foreach ($adatok['tetel_lista'] as $tetel) {
    $pdf->Cell(60, 10, $tetel['termek'], 1);
    $pdf->Cell(30, 10, $tetel['darab'], 1, 0, 'C');
    $pdf->Cell(40, 10, number_format($tetel['netar'], 0, ',', ' '), 1, 0, 'R');
    $pdf->Cell(50, 10, number_format($tetel['osszeg'], 0, ',', ' '), 1, 1, 'R');
}

$pdf->Ln(5);
$pdf->SetFont('DejaVu','',12);
$pdf->Cell(0, 10, 'Végösszeg: ' . number_format($adatok['teljes_osszeg'], 0, ',', ' ') . ' Ft', 0, 1, 'R');

// Céges adatok, aláírás
$pdf->Ln(10);
$pdf->SetFont('DejaVu','',10);
$pdf->MultiCell(0, 6, "InnovTrade Kft.
info@innovtrade.hu
Adószám: 12345678-1-42
Székhely: 1111 Budapest, Fő utca 1.");

$pdf->Ln(12);
$pdf->Cell(0, 10, '__________________________', 0, 1, 'R');
$pdf->Cell(0, 6, 'InnovTrade ügyvezető', 0, 1, 'R');

$filename = __DIR__ . "/szamla_" . md5($adatok['felhasznalo_email']) . ".pdf";
$pdf->Output('F', $filename);
$_SESSION['szamla_fajl'] = $filename;
?>
