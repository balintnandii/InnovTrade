<?php
// pdf/pdf_generalas.php

session_start();

require_once __DIR__ . '/../fpdf/fpdf.php';

if (!isset($_SESSION['szamla_adatok'])) {
    die("❌ Nincsenek számla adatok!");
}

$adatok = $_SESSION['szamla_adatok'];
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'InnovTrade Számla', 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Név: ' . $adatok['felhasznalo_nev'], 0, 1);
$pdf->Cell(0, 10, 'Email: ' . $adatok['felhasznalo_email'], 0, 1);
$pdf->Cell(0, 10, 'Dátum: ' . $adatok['datum'], 0, 1);
$pdf->Cell(0, 10, 'Számlaszám: ' . $adatok['szamla_sorszam'], 0, 1);
$pdf->Ln(5);

$pdf->Cell(60, 10, 'Autó', 1);
$pdf->Cell(30, 10, 'Óra', 1);
$pdf->Cell(40, 10, 'Óradíj (Ft)', 1);
$pdf->Cell(50, 10, 'Összesen (Ft)', 1);
$pdf->Ln();

foreach ($adatok['tetel_lista'] as $tetel) {
    $pdf->Cell(60, 10, $tetel['termek'], 1);
    $pdf->Cell(30, 10, $tetel['darab'], 1);
    $pdf->Cell(40, 10, number_format($tetel['netar'], 0, ',', ' '), 1);
    $pdf->Cell(50, 10, number_format($tetel['osszeg'], 0, ',', ' '), 1);
    $pdf->Ln();
}

$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Végösszeg: ' . number_format($adatok['teljes_osszeg'], 0, ',', ' ') . ' Ft', 0, 1);

$filename = __DIR__ . "/szamla_" . md5($adatok['felhasznalo_email']) . ".pdf";
$pdf->Output('F', $filename);
$_SESSION['szamla_fajl'] = $filename;
?>
