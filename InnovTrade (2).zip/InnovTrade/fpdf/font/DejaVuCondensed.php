
<?php
$type = 'TrueType';
$name = 'DejaVuSansCondensed';
$desc = array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>928,'Flags'=>32,'FontBBox'=>'[-664 -236 2000 928]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>600);
$up = -63;
$ut = 44;
$cw = array_fill(0, 256, 600);
$enc = 'cp1252';
$uv = array();
$file = '';
$originalsize = 0;
$subsetted = false;
?>
