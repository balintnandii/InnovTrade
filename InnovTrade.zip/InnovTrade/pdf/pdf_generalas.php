<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../fpdf/fpdf.php';

if (!isset($_SESSION['szamla_adatok'])) {
    exit("❌ Nincsenek számla adatok.");
}

$adatok = $_SESSION['szamla_adatok'];
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);
$pdf->SetTitle('InnovTrade Szamla');
$pdf->SetAuthor('InnovTrade');

// 🖼 Céges logó és név középen
$logoPath = __DIR__ . '/../kepek/logo.png';
if (file_exists($logoPath)) {
    $pdf->Image($logoPath, 90, 10, 30); // középre igazított logó
    $pdf->SetY(45);
} else {
    $pdf->SetY(15);
}

// 📦 Fejléc
$pdf->SetFillColor(52, 152, 219);
$pdf->SetTextColor(255);
$pdf->SetFont('Arial', 'B', 18);
$pdf->Cell(0, 12, 'InnovTrade Szamla', 0, 1, 'C', true);
$pdf->Ln(5);

// 🧾 Ügyféladatok
$pdf->SetTextColor(0);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 8, 'Megrendelo neve: ' . $adatok['felhasznalo_nev'], 0, 1);
$pdf->Cell(0, 8, 'Email: ' . $adatok['felhasznalo_email'], 0, 1);
$pdf->Cell(0, 8, 'Datum: ' . $adatok['datum'], 0, 1);
$pdf->Cell(0, 8, 'Szamlaszam: ' . $adatok['szamla_sorszam'], 0, 1);
$pdf->Ln(6);

// 🧾 Kosár tartalom táblázat
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(60, 10, 'Auto', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Napok szama', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Napidij (Ft)', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Osszesen (Ft)', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 10);
foreach ($adatok['tetel_lista'] as $tetel) {
    $pdf->Cell(60, 10, $tetel['termek'], 1);
    $pdf->Cell(30, 10, $tetel['darab'], 1, 0, 'C');
    $pdf->Cell(40, 10, number_format($tetel['netar'], 0, ',', ' '), 1, 0, 'R');
    $pdf->Cell(50, 10, number_format($tetel['osszeg'], 0, ',', ' '), 1, 1, 'R');
}
$pdf->Ln(6);

// 💰 Végösszeg
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Vegosszeg: ' . number_format($adatok['teljes_osszeg'], 0, ',', ' ') . ' Ft', 0, 1, 'R');

// 🏢 Céges adatok
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 6, "InnovTrade Kft.\nEmail: info@innovtrade.hu\nAdoszam: 12345678-1-42\nSzekhely: 1111 Budapest, Fo utca 1.\nTelefonszam: +36 1 234 5678\nBankszamlaszam: 11700000-12345678");

$pdf->Ln(8);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(100);
$pdf->MultiCell(0, 6, "Koszonjuk, hogy az InnovTrade szolgaltatasat valasztotta!\nA szamla elektronikus formatumban ervenyes, es kerjuk, orizze meg.\nUgyfelszolgalatunk 0-24 elerheto a fenti elerhetosegeken.");

// 🔳 QR-kód letöltése és beillesztése
$qr_content = urlencode("Szamlaszam: {$adatok['szamla_sorszam']}\nVegosszeg: {$adatok['teljes_osszeg']} Ft");
$qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . $qr_content;
$qr_image_path = __DIR__ . "/qr_temp.png";

file_put_contents($qr_image_path, file_get_contents($qr_url));

if (file_exists($qr_image_path)) {
    $pdf->Image($qr_image_path, 160, 240, 30);
}

// 🖼 Szegély
$pdf->SetDrawColor(150, 150, 150);
$pdf->Rect(5, 5, 200, 287);

// 💾 Mentés
$filename = __DIR__ . "/szamla_" . md5($adatok['felhasznalo_email']) . ".pdf";
$pdf->Output('F', $filename);
$_SESSION['szamla_fajl'] = $filename;

// 🧹 QR-kép törlése
if (file_exists($qr_image_path)) {
    unlink($qr_image_path);
}
?>
