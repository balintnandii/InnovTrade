<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function utftohuf($string) {
    $string = iconv('utf-8','ISO-8859-2',$string);
    return $string;
}
require_once __DIR__ . '/../fpdf/fpdf.php';

if (!isset($_SESSION['szamla_adatok'])) {
    exit("❌ Nincsenek számla adatok.");
}

$adatok = $_SESSION['szamla_adatok'];
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);
$pdf->SetTitle('InnovTrade Szamla');
$pdf->SetAuthor('InnovTrade');

// 🖼 Céges logó és név középen
$logoPath = __DIR__ . '/../kepek/logo.png';
if (file_exists($logoPath)) {
    $pdf->Image($logoPath, 90, 10, 30); // középre igazított logó
    $pdf->SetY(45);
} else {
    $pdf->SetY(15);
}

// 📦 Fejléc
$pdf->SetFillColor(52, 152, 219);
$pdf->SetTextColor(255);
$pdf->SetFont('Arial', 'B', 18);
$pdf->Cell(0, 12, utftohuf('InnovTrade Számla'), 0, 1, 'C', true);
$pdf->Ln(5);

// 🧾 Ügyféladatok
$pdf->SetTextColor(0);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 8, utftohuf('Megrendelő neve:') . $adatok['felhasznalo_nev'], 0, 1);
$pdf->Cell(0, 8, 'Email: ' . $adatok['felhasznalo_email'], 0, 1);
$pdf->Cell(0, 8, utftohuf('Dátum: ') . $adatok['datum'], 0, 1);
$pdf->Cell(0, 8, utftohuf('Számlaszám: ') . $adatok['szamla_sorszam'], 0, 1);
$pdf->Ln(6);

// 🧾 Kosár tartalom táblázat
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(60, 10, utftohuf('Autó neve'), 1, 0, 'C', true);
$pdf->Cell(30, 10, utftohuf('Napok száma'), 1, 0, 'C', true);
$pdf->Cell(40, 10, utftohuf('Napidíj (Ft)'), 1, 0, 'C', true);
$pdf->Cell(50, 10, utftohuf('Összesen (Ft)'), 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 10);
foreach ($adatok['tetel_lista'] as $tetel) {
    $pdf->Cell(60, 10, $tetel['termek'], 1);
    $pdf->Cell(30, 10, $tetel['darab'], 1, 0, 'C');
    $pdf->Cell(40, 10, number_format($tetel['netar'], 0, ',', ' '), 1, 0, 'R');
    $pdf->Cell(50, 10, number_format($tetel['osszeg'], 0, ',', ' '), 1, 1, 'R');
}
$pdf->Ln(6);

// 💰 Végösszeg
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, utftohuf('Végösszeg: ') . number_format($adatok['teljes_osszeg'], 0, ',', ' ') . ' Ft', 0, 1, 'R');

// 🏢 Céges adatok
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 10);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, utf8_decode("Köszönjük, hogy az InnovTrade szolgáltatását választotta!"), 0, 1);
$pdf->Cell(0, 6, utf8_decode("A számla elektronikus formátumban érvényes, kérjük őrizze meg."), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Ügyfélszolgálatunk 0-24 elérhető a fenti elérhetőségeken."), 0, 1);

$pdf->Ln(8);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(100);
$pdf->Ln(6);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, utf8_decode("InnovTrade Kft."), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Email: info@innovtrade.hu"), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Adószám: 12345678-1-42"), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Székhely: 1111 Budapest, Fő utca 1."), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Telefonszám: +36 1 234 5678"), 0, 1);
$pdf->Cell(0, 6, utf8_decode("Bankszámlaszám: 11700000-12345678"), 0, 1);

// 🔳 QR-kód letöltése és beillesztése
$qr_content = urlencode("Szamlaszam: {$adatok['szamla_sorszam']}\nVegosszeg: {$adatok['teljes_osszeg']} Ft");
$qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . $qr_content;
$qr_image_path = __DIR__ . "/qr_temp.png";

file_put_contents($qr_image_path, file_get_contents($qr_url));

if (file_exists($qr_image_path)) {
    $pdf->Image($qr_image_path, 160, 240, 30);
}

// 🖼 Szegély
$pdf->SetDrawColor(150, 150, 150);
$pdf->Rect(5, 5, 200, 287);

// 💾 Mentés
$filename = __DIR__ . "/szamla_" . md5($adatok['felhasznalo_email']) . ".pdf";
$pdf->Output('F', $filename);
$_SESSION['szamla_fajl'] = $filename;

// 🧹 QR-kép törlése
if (file_exists($qr_image_path)) {
    unlink($qr_image_path);
}
?>
