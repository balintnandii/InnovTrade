<?php session_start(); ?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Köszönjük a foglalást</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0fdf4;
            text-align: center;
            padding: 50px;
        }
        .container {
            background: white;
            border-radius: 12px;
            padding: 40px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .checkmark {
            font-size: 80px;
            color: green;
        }
        h1 {
            color: #2e7d32;
        }
        p {
            font-size: 18px;
            color: #333;
        }
        .button {
            margin-top: 30px;
            padding: 10px 20px;
            background-color: #2e7d32;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 16px;
        }
        .button:hover {
            background-color: #1b5e20;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkmark">✅</div>
        <h1>Köszönjük a foglalást, <?php echo $_SESSION['felhasznalo'] ?? 'Kedves ügyfél'; ?>!</h1>
        <p>A számlát elküldtük a(z) <strong><?php echo $_SESSION['email'] ?? 'ismeretlen'; ?></strong> címre.</p>
        <a class="button" href="index.php">Vissza a főoldalra</a>
    </div>
</body>
</html>
