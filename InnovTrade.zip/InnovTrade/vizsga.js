document.addEventListener("DOMContentLoaded", function() {
    window.kategoriaMegjelenites = function(kategoriaId) {
        let kategoriak = document.getElementsByClassName("kategoria");
        for (let i = 0; i < kategoriak.length; i++) {
            kategoriak[i].style.display = "none";
        }
        let kivalasztott = document.getElementById(kategoriaId);
        if (kivalasztott) {
            kivalasztott.style.display = "block";
        }
    };

    let kosar = JSON.parse(sessionStorage.getItem("kosar")) || [];
    let kedvezmenySzazalek = 0;
    let fizetesiMod = "";

    function mentKosar() {
        sessionStorage.setItem("kosar", JSON.stringify(kosar));
    }

    function frissitKosar() {
        const kosarLista = document.getElementById("kosar-lista");
        const vegosszegElem = document.getElementById("vegosszeg-kijelzes");
        if (kosarLista) kosarLista.innerHTML = "";

        let vegosszeg = 0;

        if (kosar.length === 0) {
            if (kosarLista) kosarLista.innerHTML = "<li>A kosár üres.</li>";
        } else {
            kosar.forEach((item, index) => {
                let li = document.createElement("li");
                li.innerHTML = `${item.nev} - ${item.ar} Ft/nap - ${item.napok} nap 
                <button class="torles-gomb" data-index="${index}" style="border:none; background:none; cursor:pointer; font-size:16px; color:red;">❌</button>`;
                if (kosarLista) kosarLista.appendChild(li);
                vegosszeg += item.ar * item.napok;
            });
        }

        if (vegosszegElem) {
            let afakulcs = 0.27;
            let kedvezmeny = vegosszeg * (kedvezmenySzazalek / 100);
            let afa = (vegosszeg - kedvezmeny) * afakulcs;
            let fizetendo = (vegosszeg - kedvezmeny) + afa;
            vegosszegElem.innerHTML = `
                <div style="margin-top: 12px; padding: 10px 14px; background: #f8f9fa; border: 1px solid #ccc; border-radius: 5px; font-weight: bold; font-size: 1rem; color: #333; text-align: left;">
                    Nettó: ${vegosszeg.toLocaleString('hu-HU')} Ft<br>
                    Kedvezmény: -${kedvezmeny.toLocaleString('hu-HU')} Ft (${kedvezmenySzazalek}%)<br>
                    ÁFA (27%): ${afa.toLocaleString('hu-HU')} Ft<br>
                    Fizetendő: <strong>${fizetendo.toLocaleString('hu-HU')} Ft</strong><br>
                    Fizetési mód: ${fizetesiMod || "Nincs kiválasztva"}
                </div>
            `;
        }

        const hiddenField = document.getElementById("foglalas-autonev-hidden");
        if (hiddenField) {
            hiddenField.value = JSON.stringify(kosar);
        }

        document.querySelectorAll(".torles-gomb").forEach(button => {
            button.addEventListener("click", function() {
                let index = this.getAttribute("data-index");
                kosar.splice(index, 1);
                mentKosar();
                frissitKosar();
            });
        });
    }

    window.hozzaadKosarhoz = function(autoNev, ar) {
        let foglalasiNapok = parseInt(document.getElementById("foglalas-ido").value) || 1;
        let letezik = kosar.find(item => item.nev === autoNev);
        if (letezik) {
            letezik.napok = foglalasiNapok;
        } else {
            kosar.push({ nev: autoNev, ar: ar, napok: foglalasiNapok });
        }
        mentKosar();
        frissitKosar();
        alert(`${autoNev} hozzáadva a kosárhoz ${foglalasiNapok} napra!`);
    };

    const foglalasIdoInput = document.getElementById("foglalas-ido");
    if (foglalasIdoInput) {
        foglalasIdoInput.addEventListener("input", () => {
            let ujNapok = parseInt(foglalasIdoInput.value) || 1;
            kosar = kosar.map(auto => ({ ...auto, napok: ujNapok }));
            mentKosar();
            frissitKosar();
        });
    }

    const kuponInput = document.getElementById("kuponkod");
    if (kuponInput) {
        kuponInput.addEventListener("input", () => {
            const kod = kuponInput.value.trim().toUpperCase();
            if (kod === "INNOV10") {
                kedvezmenySzazalek = 10;
            } else {
                kedvezmenySzazalek = 0;
            }
            frissitKosar();
        });
    }

    document.querySelectorAll('input[name="fizetes"]').forEach(radio => {
        radio.addEventListener("change", function() {
            fizetesiMod = this.value;
            frissitKosar();

            if (fizetesiMod === "Átutalás") {
                window.location.href = "bankkartyas_oldal.php";
            }
        });
    });

    frissitKosar();

    let overlay = document.getElementById("overlay");
    let regisztracioElem = document.getElementById("regisztracio");
    let belepesElem = document.getElementById("belepes");

    let regisztracioGomb = document.getElementById("regisztracio-gomb");
    if (regisztracioGomb) {
        regisztracioGomb.addEventListener("click", function() {
            regisztracioElem.style.display = "block";
            belepesElem.style.display = "none";
            overlay.style.display = "block";
        });
    }

    let belepesGomb = document.getElementById("belepes-gomb");
    if (belepesGomb) {
        belepesGomb.addEventListener("click", function() {
            belepesElem.style.display = "block";
            regisztracioElem.style.display = "none";
            overlay.style.display = "block";
        });
    }

    function zarasFelulet() {
        if (regisztracioElem) regisztracioElem.style.display = "none";
        if (belepesElem) belepesElem.style.display = "none";
        if (overlay) overlay.style.display = "none";
    }

    if (overlay) {
        overlay.addEventListener("click", zarasFelulet);
    }

    window.velemenyHozzaadasa = function() {
        let autoNev = document.getElementById("velemeny-autonev").value;
        let szoveg = document.getElementById("velemeny-szoveg").value;
        if (autoNev && szoveg) {
            let lista = document.getElementById("velemenyek-lista");
            lista.innerHTML += `<p><strong>${autoNev}</strong>: ${szoveg}</p>`;
            alert("Köszönjük a véleményed!");
            document.getElementById("velemeny-urlap").reset();
        } else {
            alert("Kérjük, tölts ki minden mezőt!");
        }
    };

    window.kapcsolatHozzaadasa = function() {
        let nev = document.getElementById("kapcsolat-nev").value;
        let email = document.getElementById("kapcsolat-email").value;
        let uzenet = document.getElementById("kapcsolat-uzenet").value;
        if (nev && email && uzenet) {
            alert(`Köszönjük, ${nev}! Válaszunkat hamarosan elküldjük.`);
            document.getElementById("kapcsolat-urlap").reset();
        } else {
            alert("Kérjük, tölts ki minden mezőt!");
        }
    };
});
