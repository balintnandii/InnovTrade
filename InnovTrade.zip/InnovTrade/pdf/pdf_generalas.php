<?php
session_start();
require('fpdf/fpdf.php');

if (!isset($_SESSION['szamla_adatok'])) {
    die("Nincs számlaadat!");
}

$adatok = $_SESSION['szamla_adatok'];

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Cím
$pdf->Cell(0, 10, 'Szamla', 0, 1, 'C');
$pdf->Ln(10);

// Felhasználó adatai
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 8, "Nev: " . $adatok['felhasznalo_nev'], 0, 1);
$pdf->Cell(0, 8, "Email: " . $adatok['felhasznalo_email'], 0, 1);
$pdf->Cell(0, 8, "Datum: " . $adatok['datum'], 0, 1);
$pdf->Cell(0, 8, "Szamla sorszam: " . $adatok['szamla_sorszam'], 0, 1);
$pdf->Ln(10);

// Tetelek fejlec
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(60, 8, 'Termek', 1);
$pdf->Cell(30, 8, 'Napok', 1);
$pdf->Cell(40, 8, 'Netto ar', 1);
$pdf->Cell(40, 8, 'Osszeg', 1);
$pdf->Ln();

// Tetelek kiirasa
$pdf->SetFont('Arial', '', 12);
foreach ($adatok['tetel_lista'] as $tetel) {
    $pdf->Cell(60, 8, $tetel['termek'], 1);
    $pdf->Cell(30, 8, $tetel['darab'], 1);
    $pdf->Cell(40, 8, number_format($tetel['netar'], 0, '', ' ') . " Ft", 1);
    $pdf->Cell(40, 8, number_format($tetel['osszeg'], 0, '', ' ') . " Ft", 1);
    $pdf->Ln();
}

$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Vegosszeg: ' . number_format($adatok['teljes_osszeg'], 0, '', ' ') . " Ft", 0, 1, 'R');

// Kimenet letöltésre
$pdf->Output('I', 'pdf/szamla_' . $adatok['szamla_sorszam'] . '.pdf');
?>
